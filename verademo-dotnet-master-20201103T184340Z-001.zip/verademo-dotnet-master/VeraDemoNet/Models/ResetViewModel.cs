﻿namespace VeraDemoNet.Controllers
{
    public class ResetViewModel
    {
        public string Error { get; set; }
    }
}