﻿namespace VeraDemoNet.Models
{
    public class ToolViewModel
    {
        public string Host { get; set; }
        public string PingResult { get; set; }
        public string FortuneResult { get; set; }
    }
}