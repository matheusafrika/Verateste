﻿namespace VeraDemoNet.Commands
{
    public interface IBlabberCommand
    {
        void Execute(string blabberUsername);
    }
}
